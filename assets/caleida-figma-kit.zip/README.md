# Caleida — Figma Kit

*The Sunday Kitchen design system, ready to rebuild in Figma.*

This kit isn't a native `.fig` file — it's the raw material a design system hands to Figma:
importable tokens, the logo as vector, and the reference you need to set up styles. Fifteen
minutes and the whole system lives in your file.

The canonical source of truth is always the live page: **/caleida-design-system**.

---

## What's inside

```
caleida.tokens.json     → import straight into the Tokens Studio plugin
tokens.w3c.json         → the same tokens in W3C DTCG format (for other tools / dev)
tokens.css              → CSS custom properties (for engineering)
svg/
  mark-diamond.svg          the mark, for light surfaces
  mark-diamond-on-dark.svg  the mark on the espresso / night surface
  favicon-diamond.svg       solid reduction, holds down to 16px
  wordmark-caleida.svg      horizontal mark + wordmark lockup
  palette-swatches.svg      the full palette, labelled
```

---

## 1 · Fonts (install these first)

All four are free (SIL Open Font License) and on Google Fonts. Install them locally so Figma
can use them.

| Role | Family | Notes |
|------|--------|-------|
| **Logotype** | **Bricolage Grotesque** | the wordmark only — weight 600, tracking −2% |
| **Display / headlines** | **Fraunces** | headlines only, weight 440–560 (opsz on) |
| **Body + UI** | **Plus Jakarta Sans** | everything functional — 400 / 500 / 700 |
| **Cal's voice** | **Shantell Sans** | Cal's chat + taped notes only, weight 500 |

- https://fonts.google.com/specimen/Bricolage+Grotesque
- https://fonts.google.com/specimen/Fraunces
- https://fonts.google.com/specimen/Plus+Jakarta+Sans
- https://fonts.google.com/specimen/Shantell+Sans

---

## 2 · Import the tokens (Tokens Studio)

1. In Figma, install the **Tokens Studio for Figma** plugin (Plugins → Tokens Studio).
2. Open it → the **…** menu → **Import** → **Load from file/folder** → choose `caleida.tokens.json`.
3. You'll get one token set, `caleida`, with `color`, `font`, `radius`, `space`, and `shadow`.
4. Select the set, then **Create styles** (bottom of the plugin) to generate Figma colour +
   text + effect styles from the tokens in one click.

Prefer another tool? Use `tokens.w3c.json` (W3C DTCG) or `tokens.css`.

---

## 3 · Or set styles up by hand

### Colour

| Token | Hex | Use |
|-------|-----|-----|
| paper | `#F7F0E3` | page / app surface |
| paper-deep | `#F0E7D3` | foot of the surface gradient |
| card | `#FFFDF6` | panels |
| note | `#FFFDF3` | Cal's note paper |
| ink | `#2A211B` | headings / primary text (14:1) |
| body | `#4A4038` | body copy (8.9:1) |
| muted | `#9C8E7E` | captions, meta |
| line | `#E8DEC9` | hairlines |
| line-2 | `#DFD3BC` | stronger dividers |
| **terracotta** | `#C05330` | THE signature — display, fills, buttons |
| terracotta-deep | `#A94525` | small terracotta text / press (5.2:1) |
| salmon | `#E0825E` | terracotta tint |
| teal | `#1F8175` | Cal acts / confirms |
| teal-deep | `#186B60` | small teal text (5.6:1) |
| gold | `#D9A23A` | highlights (small areas only) |
| gold-soft | `#F3E2B8` | sticky labels |
| gold-ink | `#8A5F10` | text on gold |
| espresso | `#211913` | night surface (not black) |
| linen | `#F4EDE0` | text on espresso |
| terracotta-glow | `#D77E57` | terracotta on dark |
| teal-glow | `#7FB6A6` | teal on dark |

**People:** you = teal `#1F8175` · partner = terracotta `#C05330` · shared = gold `#D9A23A` ·
Cal = the diamond. Always pair a person colour with an initial, never colour alone.

### Type scale

| Style | Family | Weight | Size | Line-height |
|-------|--------|--------|------|-------------|
| Logotype | Bricolage Grotesque | 600 | — | tracking −2% |
| Display | Fraunces | 520 | 64 (clamp 40–74) | 1.05 |
| H1 | Fraunces | 520 | 52 | 1.05 |
| H2 | Fraunces | 540 | 36 | 1.1 |
| H3 | Plus Jakarta Sans | 700 | 20 | 1.3 |
| Body | Plus Jakarta Sans | 400/500 | 16 | 1.65 |
| Small | Plus Jakarta Sans | 500 | 14 | 1.5 |
| Caption | Plus Jakarta Sans | 600 | 12.5 | 1.4 · uppercase, tracked .08em |
| Cal's voice | Shantell Sans | 500 | 15–16 | 1.5 |

### Radius · shadow · spacing

- **Radius:** card 14 · button 12 · input 10 · note 3 · icon 18 · pill 999
- **Shadow (one warm light, top-left):** `sh-1` 0 1 2 rgba(58,40,26,.10) · `sh-2` add 0 8 18 rgba(58,40,26,.10) · `sh-3` add 0 16 34 rgba(58,40,26,.13)
- **Spacing (8pt):** 4 · 8 · 12 · 16 · 20 · 24 · 32 · 40 · 56 · container 1060

---

## 4 · The mark

One mark at every size — the four-facet diamond (a kaleidoscope simplified to its facets).
Cream gaps turn the segments into facets; the 45° turn reads as a gem, not a pie chart.

- **`mark-diamond.svg`** — light surfaces (gaps = paper).
- **`mark-diamond-on-dark.svg`** — espresso surface; pigments lift to their glow tints.
- **`favicon-diamond.svg`** — solid reduction; below ~20px the gaps close and the diamond does the work.
- **`wordmark-caleida.svg`** — horizontal lockup (needs Bricolage Grotesque installed to render the word).

Never: recolour outside the palette · add gloss/bevel/shadow · stretch or re-space · set the
wordmark in any face other than Bricolage Grotesque · lift the kaleidoscope out of the logo as a motif.

---

## 5 · Components to build (specs)

- **Primary button** — glazed terracotta `linear-gradient(#CF6238, #C05330 55%, #A94525)`, radius 12, white text `#FFFDF8`, 1px inner-light + 2px inner-dark "press", depresses 1px on tap.
- **Card** — `#FFFDF6`, 1px `#E8DEC9`, radius 14, shadow sh-2.
- **Gold sticky label (chip)** — `linear-gradient(#FBEFD2, #F3E2B8)`, gold-ink text, radius 5–6.
- **Cal's bubble** — note paper `#FFFDF3`, radius 3 (a real paper corner), shadow sh-2, text in Shantell Sans; confirms stay Plus Jakarta 700 in teal.
- **Invisible-work mirror** — a split bar (her / you / shared), never streaks, badges, or a leaderboard.

---

## Doctrine, in one line

Kaleidoscope lives in the logo only · Cal speaks in the warm roast (his handwriting) · the
Invisible Work screen is a mirror, never a scoreboard · a household companion, not a task app.

*Caleida — The Sunday Kitchen · built 2026.*
